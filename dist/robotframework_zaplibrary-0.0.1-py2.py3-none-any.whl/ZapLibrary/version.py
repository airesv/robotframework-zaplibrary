#!/usr/bin/env python
# -*- coding: utf-8 -*-

#    Copyright 2017 Vitor Aires <airesv@gmail.com>


"""
ZAP Library - a OWASP ZAP testing library. 
"""

VERSION = '0.0.1'


def get_version():
    """Returns the current version."""
    return VERSION